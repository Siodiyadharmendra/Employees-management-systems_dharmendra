<?php

if(isset($_POST['sbmt'])){

    echo $name = $_POST['username'];
    echo $email = $_POST['useremail'];
    echo $password = $_POST['userpassword'];
    echo $mobile = $_POST['usermobile'];


    // Checking data empty or not
    if ($name != "" && $email != "" && $password != "" && $mobile != "") {

        // Start performing query using db [INSERT]

        // 1. Connecting Project to Database
        $conn = mysqli_connect("localhost", "root", "", "users_");

        // 2. Checking Connectiong working or not
        if (!$conn) {
            die("Error in Connecting DB" . mysqli_connect_error());
        }else{

            // 3. prepare query
            $updateUser = "UPDATE `users_` SET `name`='$name',`password`='$password',`mobile`='$mobile' WHERE `email`='$email'";

            if(mysqli_query($conn,$updateUser)){

                ?>
                    <script>
                        alert("Data Updated successfully");
                        window.location.href="viewuser.php";
                    </script>
                <?php

            }else{
                echo "Error in update data : ".mysqli_error($conn);
            }

        }
        
    }


}

?>