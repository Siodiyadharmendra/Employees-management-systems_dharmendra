<?php
session_start();
if(isset($_SESSION['email'])){

}else{
    header("Location:login.php");
}
?>
<?php

if(isset($_SESSION['email'])){

}else{
    header("Location:ragistration.php");
}
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
</head>

<body class="bg-primary">


    <!-- Include Header Start -->
    <?php include("include/header.php"); ?>
    <!-- Include Header End -->




    <section class="container py-5">
        <div class="row justify-content-center py-5">
            <div class="col-12 col-md-11">
                <table class="table table-hover table-responsive bg-light" id="myTable">
                    <!-- Table Header  -->
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Mobile</th>
                        <th>Update</th>
                        <th>Delete</th>
                    </tr>

                    <?php

                    // 1. Connecting Project to Database
                    $conn = mysqli_connect("localhost", "root", "", "users_");

                    // 2. Checking Connectiong working or not
                    if (!$conn) {
                        die("Error in Connecting DB" . mysqli_connect_error());
                    } else {


                        // 3. SELECT query for user  
                        $userSelect = "SELECT * FROM `users_`";

                        // 4. Execute query ( select query ) and store result in result    
                        $result = mysqli_query($conn, $userSelect);

                        if (mysqli_num_rows($result) > 0) {

                            while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                                <!--  execute loop with html -->
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['email']; ?></td>
                                    <td><?php echo $row['password']; ?></td>
                                    <td><?php echo $row['mobile']; ?></td>

                                    <td><a href="updateuser.php?id=<?php echo $row['id'] ?>" class="btn btn-warning">Update</a> </td>

                                    <td><a href="deleteuser.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">Delete</a> </td>
                                </tr>

                    <?php
                            }
                        } else {

                            echo "No Data Found";
                        }
                    }


                    ?>
                </table>
            </div>
        </div>
    </section>

    








    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script>
    $(document).ready(function() {
      $('#myTable').DataTable();
    });

  </script>
</body>

</html>