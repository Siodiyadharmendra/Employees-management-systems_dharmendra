<?php

session_start();

if (isset($_POST['sbmt'])) {

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$password = $_POST['password'];
$mobile = $_POST['mobile'];

if ($firstname != "" AND $lastname != ""  AND $email!= "" AND $password != "" AND $mobile!= "") {

$conn = mysqli_connect("localhost", "root", "", "ragistration_");

if (!$conn) {
    die("Error in Connecting DB" . mysqli_connect_error());
} else

{
    $sql="SELECT * FROM `ragistration_` WHERE `firstname` ='$firstname' AND `lastname`='$lastname' AND `email`='$email' AND `password`='$password' AND `mobile`='$mobile'";
    $rows = mysqli_query($conn, $sql);
    if (mysqli_num_rows($rows) === 1) {

        $data = mysqli_fetch_assoc($rows);
        if ($data['firstname'] === $firstname && $data['lastname'] === $lastname && $data['email']=== $email && $data['password']=== $password && $data['mobile']=== $mobile){
            $_SESSION['email'] = $data['email'];
?>
<script>
                        alert("ragistation Successfully");
                        window.location.href = "index.php";
                    </script>
                     
                     <?php
                      } else {
                        ?>
        
                            <script>
                                alert("incorred ragistation... Try Again...!!");
                                window.location.href = "ragistration.php";
                            </script>
<?php
 }
} else {

    ?>
    <script>
        alert(" incorred ragistation... Try Again...!!");
        window.location.href = "ragistration.php";
    </script>

<?php
}
}
}
} else {
header("Location: ragistration.php");
}



