<header class="bg-light">
  <nav class="container navbar navbar-expand-lg navbar-dark bg-dark ">
    <div class="container-fluid">
      <h2><a class="navbar-brand text-primary" href="index.php">home</a></h2>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-between" id="navbarNav">
        <ul class="navbar-nav ">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Admin</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Employee</a>
          </li>
          <?php

          if (isset($_SESSION['email'])) {
          ?>
            <li class="nav-item">
              <a class="nav-link" href="adduser.php"> add employee</a>
            </li>
            <!-- <li class="nav-item">
              <a class="nav-link" href="adduser.php">empolyee task</a>
            </li> -->
            <li class="nav-item">
              <a class="nav-link" href="viewuser.php">employee view</a>
            </li>
          <?php
          }
          ?>

        </ul>
        <ul class="navbar-nav ">
          <?php

          if (isset($_SESSION['email'])) {
          ?>
            <li class="nav-item">
              <a class="nav-link text-primary" href="logout.php"><strong>Logout</strong></a>
            </li>
          <?php
          } else {
          ?>
            <li class="nav-item">
              <a class="nav-link text-primary" href="login.php"><strong>Login</strong></a>
            </li>
          <?php
          }

          ?>
        </ul>
        <ul class="navbar-nav ">
          <?php

          if (isset($_SESSION['email'])) {
          ?>
            <!-- <li class="nav-item">
              <a class="nav-link text-primary" href="logout.php"><strong>Logout</strong></a>
            </li> -->
          <?php
          } else {
          ?>
            <li class="nav-item">
              <a class="nav-link text-primary" href="ragistration.php"><strong>ragistation</strong></a>
            </li>
          <?php
          }

          ?>
        </ul>
      </div>
    </div>
  </nav>

</header>